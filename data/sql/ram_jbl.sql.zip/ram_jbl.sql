-- phpMyAdmin SQL Dump
-- version 3.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2015 at 10:52 AM
-- Server version: 5.1.47
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ram_jbl`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_user` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `admin_user`, `admin_pass`) VALUES
(1, 'super', '1b3231655cebb7a1f783eddf27d254ca');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `image`, `status`, `updated_at`, `created_at`) VALUES
(1, 'DAK<br>Canned Meats', 'image.jpg', 0, '2014-05-13 11:33:24', '2011-09-27 15:43:02'),
(2, 'DAK<br>Hotdog & Cocktail Sausages', 'image.jpg', 0, '2014-05-13 11:33:30', '2011-09-27 15:43:22'),
(3, 'Pietro Coricelli', 'image.jpg', 0, '2011-09-27 15:43:48', '2011-09-27 15:43:48'),
(4, 'Pietro Coricelli<br>The Italian Art of Olive Oil', 'image.jpg', 0, '2011-09-27 15:45:17', '2011-09-27 15:45:17'),
(5, 'Pietro Coricelli<br>Extra Virgin Olive Oil Range', 'image.jpg', 0, '2011-09-27 15:45:42', '2011-09-27 15:45:42'),
(6, 'Pietro Coricelli<br>Fruttato Gran Classe', 'image.jpg', 0, '2011-09-27 15:46:02', '2011-09-27 15:46:02'),
(7, 'Pietro Coricelli<br>Aceto Balsamico di Modena', 'image.jpg', 0, '2011-09-27 15:46:28', '2011-09-27 15:46:28'),
(8, 'Pietro Coricelli<br>100% Pure Olive Oil', 'image.jpg', 0, '2011-09-27 15:46:53', '2011-09-27 15:46:53'),
(9, 'Pietro Coricelli<br>Extra Virgin Olive Oil', 'image.jpg', 0, '2011-09-27 15:47:15', '2011-09-27 15:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `text` text,
  `image` varchar(50) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `title`, `text`, `image`, `updated_at`, `created_at`) VALUES
(1, '<dd>Lorem Ipsum is</dd> simply dummy text title 1', '<p class="nivop">Lorem Ipsum is simply dummy text of the printing and typesetting  industry. Lorem Ipsum has been the industry''s standard dummy text ever  since the 1500s, when an unknown printer took a galley of type and  scrambled it to make a type specimen book. It has survived not only five  centuries, but also the leap into electronic typesetting, remaining  essentially unchanged.</p>\r\n<p class="nivop">It was popularised in the 1960s with the release  of Letraset sheets containing Lorem Ipsum passages, and more recently  with desktop publishing software like Aldus PageMaker including versions  of Lorem Ipsum.</p>', '1_3_slide1.jpg', '2014-04-29 17:26:11', NULL),
(2, '<dd>Lorem Ipsum is</dd> simply dummy text title 2', '<p class="nivop">Lorem Ipsum is simply dummy text of the printing and typesetting  industry. Lorem Ipsum has been the industry''s standard dummy text ever  since the 1500s, when an unknown printer took a galley of type and  scrambled it to make a type specimen book. It has survived not only five  centuries, but also the leap into electronic typesetting, remaining  essentially unchanged.</p>\r\n<p class="nivop">It was popularised in the 1960s with the release  of Letraset sheets containing Lorem Ipsum passages, and more recently  with desktop publishing software like Aldus PageMaker including versions  of Lorem Ipsum.</p>', '2_slide2.jpg', '2014-04-29 17:31:29', NULL),
(3, '<dd>Lorem Ipsum is</dd> simply dummy text title 3', '<p class="nivop">Lorem Ipsum is simply dummy text of the printing and typesetting  industry. Lorem Ipsum has been the industry''s standard dummy text ever  since the 1500s, when an unknown printer took a galley of type and  scrambled it to make a type specimen book. It has survived not only five  centuries, but also the leap into electronic typesetting, remaining  essentially unchanged.</p>\r\n<p class="nivop">It was popularised in the 1960s with the release  of Letraset sheets containing Lorem Ipsum passages, and more recently  with desktop publishing software like Aldus PageMaker including versions  of Lorem Ipsum.</p>', '3_slide1.jpg', '2014-04-29 17:31:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title`, `image`, `status`, `updated_at`, `created_at`) VALUES
(1, 'Olive Oil, Extra Vergin Oil &amp; Balsamic Vinegar', 'image.jpg', 1, '2014-09-15 12:25:06', '2011-09-27 15:17:44'),
(2, 'Maasdam Cheese &amp; Edam Loaves', 'image.jpg', 1, '2014-05-13 10:46:04', '2011-09-27 15:18:27'),
(3, 'Pasta', 'image.jpg', 1, '2014-04-29 11:19:21', '2011-09-27 15:18:55'),
(4, 'Canned Tomatoes &amp; Passata', 'image.jpg', 1, '2014-04-29 11:19:22', '2011-09-27 15:19:29'),
(5, 'Canned Meats &amp; Cooked Chicken Breast', 'image.jpg', 1, '2014-04-29 11:19:24', '2011-09-27 15:20:21'),
(6, 'Canned Vegetables', 'image.jpg', 1, '2014-04-29 11:19:24', '2011-09-27 15:20:58'),
(7, 'Wet Cat &amp; Dog Food', 'image.jpg', 1, '2014-04-29 11:19:25', '2011-09-27 15:21:32'),
(8, 'Canned Fruit, Artichokes &amp; Mashrooms', 'image.jpg', 1, '2011-09-27 15:22:30', '2011-09-27 15:22:17'),
(9, 'Italian Salami', 'image.jpg', 1, '2011-09-27 15:28:05', '2011-09-27 15:24:02'),
(11, 'Olives', 'image.jpg', 1, '2011-09-27 15:27:57', '2011-09-27 15:26:50'),
(12, 'Sliced &amp; Grated Cheese', 'image.jpg', 1, '2011-09-27 15:27:56', '2011-09-27 15:27:36'),
(13, 'Caviar', 'image.jpg', 1, '2014-04-28 17:40:36', '2011-09-27 15:28:46'),
(14, 'Tuna &amp; Corn Beef', 'image.jpg', 1, '2014-04-28 17:40:36', '2011-09-27 15:29:07'),
(15, 'Italian Mortadella', 'image.jpg', 1, '2014-04-28 17:40:36', '2011-09-27 15:29:30'),
(16, 'Smoked Salmon &amp; Trimmings', 'image.jpg', 1, '2014-04-28 17:40:37', '2011-09-27 15:29:57'),
(17, 'Juices, Ice Teas &amp; Nectars', 'image.jpg', 1, '2014-04-28 17:40:38', '2011-09-27 15:31:03'),
(18, 'Grated Cheese', 'image.jpg', 1, '2014-04-28 17:40:39', '2011-09-27 15:31:28'),
(19, 'Granny''s Pride Honey &amp; Carob Syrup', 'image.jpg', 1, '2014-05-13 10:53:52', '2011-09-27 15:32:05'),
(20, 'Jam, Marmalade &amp; Jelly', 'image.jpg', 1, '2011-09-30 17:54:22', '2011-09-27 15:32:30'),
(21, 'Cheddar Cheeses', 'image.jpg', 1, '2014-04-28 17:40:41', '2011-09-27 15:33:49'),
(22, 'Canned Mussels', 'image.jpg', 1, '2014-04-28 17:40:46', '2011-09-27 15:34:16'),
(23, 'Pepato &amp; Romano Cheese', 'image.jpg', 1, '2014-04-28 17:40:47', '2011-09-27 15:34:42'),
(24, 'Olives', 'image.jpg', 1, '2014-04-28 17:40:48', '2011-09-27 15:35:05'),
(25, 'Cat Litter', 'image.jpg', 1, '2014-04-28 17:40:48', '2011-09-27 15:37:02'),
(26, 'Sun Flower Oils', 'image.jpg', 1, '2014-04-28 17:40:49', '2011-09-27 15:37:27'),
(27, 'Prosciutto Crudo', 'image.jpg', 1, '2014-04-28 17:40:51', '2011-09-27 15:37:58'),
(28, 'Various Cheeses', 'image.jpg', 1, '2014-04-28 17:40:51', '2011-09-27 15:38:25'),
(29, 'UHT &amp; Flavoured Milk', 'image.jpg', 1, '2014-04-28 17:40:53', '2011-09-27 15:39:21'),
(30, 'Salami', 'image.jpg', 1, '2014-04-28 17:40:55', '2011-09-27 15:39:42'),
(31, 'Italian Parmigiano Reggiano &amp; Grana Padano Cheese', 'image.jpg', 1, '2014-04-28 17:40:54', '2011-09-27 15:40:16'),
(35, 'test', 'image.jpg', 1, '2014-04-28 17:48:40', '2013-08-24 10:38:44');

-- --------------------------------------------------------

--
-- Table structure for table `subproduct`
--

CREATE TABLE IF NOT EXISTS `subproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subproduct_FI_1` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `subproduct`
--

INSERT INTO `subproduct` (`id`, `product_id`, `title`, `image`, `updated_at`, `created_at`) VALUES
(32, 2, 'test', '2_product_image_1.jpg', '2014-05-02 11:48:38', '2014-05-02 11:48:38'),
(30, 1, NULL, '1_product_image_1.jpg', '2014-04-28 17:27:46', '2014-04-28 17:27:46'),
(31, 1, 'test', '1_product_image_2.jpg', '2014-04-29 10:21:18', '2014-04-29 10:21:18');
